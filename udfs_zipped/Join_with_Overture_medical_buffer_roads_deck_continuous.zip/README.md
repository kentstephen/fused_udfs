# Join_with_Overture_medical_buffer_roads_deck_continuous

Read a Parquet or Geoparquet file and join with Overture.



# USGS_snake_river_elev_pt_2

Read a GeoTIFF image file.



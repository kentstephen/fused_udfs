# NetCDF_File

Read a NetCDF image file with rioxarray.



#fire version one ["B12", "B11", "B8A"]
# Or for even more dramatic burn scars:
# "band_list": ["B11", "B12", "B8A"],  # Swap B12 and B11

# Or for burn scar emphasis, try this band combo instead:
# "band_list": ["B12", "B8A", "B04"],  # SWIR2, NIR, Red
# USGS_snake_river_oct_2025

Read a GeoTIFF image file.



# egypt_ndvi_nile_h3_spring_2021_parquet

Read a Parquet or Geoparquet file.



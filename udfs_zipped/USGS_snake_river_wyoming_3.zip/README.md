# USGS_snake_river_wyoming_3

Read a GeoTIFF image file.



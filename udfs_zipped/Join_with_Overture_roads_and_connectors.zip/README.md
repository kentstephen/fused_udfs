# Join_with_Overture_roads_and_connectors

Read a Parquet or Geoparquet file and join with Overture.



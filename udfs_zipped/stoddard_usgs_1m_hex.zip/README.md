# stoddard_usgs_1m_hex


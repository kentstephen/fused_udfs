# alpha_overture_fsq


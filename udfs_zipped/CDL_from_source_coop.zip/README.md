# CDL_from_source_coop

## Overview

Explore the Crop Data Layer data in hex form

Data available on [Source Coop](https://source.coop/repositories/fused/hex/description).



# bfp_EGY_parquet

Read a Parquet or Geoparquet file with DuckDB.



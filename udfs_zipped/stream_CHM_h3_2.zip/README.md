# stream_CHM_h3_2

Get Canopy Height Map from Meta's open dataset on AWS




    # if suffix:
    #     path += f'_{suffix}'
    # print(path)
    # gdf = common.table_to_tile(
    #     tile,
    #     path,
    #     # use_columns=['GEOID','geometry'],
    #     min_zoom=10
    # ) 
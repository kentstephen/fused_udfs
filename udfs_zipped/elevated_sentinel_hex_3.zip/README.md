# elevated_sentinel_hex_3


# Mount_Denali_DEM_Sentinel_2


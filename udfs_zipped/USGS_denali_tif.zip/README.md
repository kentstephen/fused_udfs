# USGS_denali_tif

Read a GeoTIFF image file.



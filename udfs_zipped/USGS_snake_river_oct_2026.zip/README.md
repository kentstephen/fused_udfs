# USGS_snake_river_oct_2026

Read a GeoTIFF image file.



# tree_census_with_meta_and_ndvi


# bu_glance_training_dataV1_parquet

Read a Parquet or Geoparquet file with DuckDB.



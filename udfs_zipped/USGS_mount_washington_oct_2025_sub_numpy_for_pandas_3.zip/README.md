# USGS_mount_washington_oct_2025_sub_numpy_for_pandas_3

Read a GeoTIFF image file.



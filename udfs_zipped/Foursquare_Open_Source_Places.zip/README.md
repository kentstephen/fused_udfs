# Foursquare_Open_Source_Places

Places of interest (POIs) from [Foursquare Open Source Places](https://opensource.foursquare.com/os-places/) hosted on [Source Coop](https://source.coop/repositories/fused/fsq-os-places)



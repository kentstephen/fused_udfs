# USGS_snake_river_wyoming_2

Read a GeoTIFF image file.



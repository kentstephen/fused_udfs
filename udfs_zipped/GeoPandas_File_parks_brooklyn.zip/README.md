# GeoPandas_File_parks_brooklyn

Read a file with GeoPandas.



# montpelier_flood_buffer_improved_works

Read a Parquet or Geoparquet file with DuckDB.



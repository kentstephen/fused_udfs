# Nsi_Overture_stephen

## Overview

Spatial join between Overture polygons and NSI points to generate risk indices for each building.



# world_temp_plinio


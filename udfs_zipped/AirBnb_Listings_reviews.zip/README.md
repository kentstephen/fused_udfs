# AirBnb_Listings_reviews

## Overview

Interactive AirBnB offer map, generated from the data located at https://insideairbnb.com/get-the-data/



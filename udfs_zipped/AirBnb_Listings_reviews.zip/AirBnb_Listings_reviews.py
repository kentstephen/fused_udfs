@fused.udf
def udf(city='New York City', resolution=9, min_count=0):
    import duckdb
    import shapely
    import geopandas as gpd
    import requests
    import re
    # set a resolution limit 
    if resolution > 11:resolution=11

    h3_utils = fused.load(
        "https://github.com/fusedio/udfs/tree/fb65aff/public/DuckDB_H3_Example/"
    ).utils
        
    @fused.cache
    def get_city_data(city):
        # downloading main file list
        print('Downloading listings...')
        listings = requests.get(
            "https://insideairbnb.com/get-the-data/"
        )
        url = None
        if listings.status_code == 200:
            html = listings.text
            regexp = "(https:\/\/data.insideairbnb.com\/\w+\S+\/listings.csv.gz)"
            # parsing the list to find the required city listings URL
            for m in re.findall(regexp, html):
                if m.split('/')[5] == city:
                    url = m
                    print('Data file located at ', url)
                    return url
        return None
    
    city = city.lower().replace(' ','-')
    url = get_city_data(city)

    if url:
        out_path = f'{city}.csv.gz'
        csv_file = fused.core.download(url=url, file_path=out_path)
        
        con = duckdb.connect(config = {'allow_unsigned_extensions': True})
        h3_utils.load_h3_duckdb(con)
        con.sql(f"""INSTALL httpfs; LOAD httpfs;""")
        # reading data with duckDB and generating H3 cells
        @fused.cache
        def read_data(url, resolution, min_count):
            
            query = """ 
            SELECT h3_h3_to_string(h3_latlng_to_cell(latitude, longitude, $resolution)) cell_id,
                   h3_cell_to_boundary_wkt(cell_id) boundary,
                    count(1) as cnt,
                    SUM(review_scores_value) * 10 as reviews
            FROM read_csv($url) 
            GROUP BY ALL
            HAVING cnt >= $min_count
            ORDER by reviews DESC LIMIT 500
            """
            df = con.sql(query, params={'url': url,'resolution': resolution, 'min_count': min_count}).df()
            return df
    
        
        df = read_data(
            url=str(csv_file), 
            resolution=resolution,
            min_count=min_count
        )
        
        gdf = gpd.GeoDataFrame(df.drop(columns=['boundary']), geometry=df.boundary.apply(shapely.wkt.loads))
        
        
        return gdf
    else:
        print('Sorry, no data file identified for your location')
        

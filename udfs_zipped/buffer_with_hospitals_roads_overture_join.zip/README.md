# buffer_with_hospitals_roads_overture_join

Read a Parquet or Geoparquet file and join with Overture.



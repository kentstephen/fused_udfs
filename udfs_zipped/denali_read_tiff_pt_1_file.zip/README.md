# denali_read_tiff_pt_1_file


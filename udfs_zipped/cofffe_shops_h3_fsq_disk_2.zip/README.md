# cofffe_shops_h3_fsq_disk_2


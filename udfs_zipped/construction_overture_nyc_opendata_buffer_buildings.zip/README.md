# construction_overture_nyc_opendata_buffer_buildings

Read a Parquet or Geoparquet file and join with Overture.



# h3_north_poles


# global_power_plants_parquet

Read a Parquet or Geoparquet file and join with Overture.



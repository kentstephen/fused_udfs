# white_spoonbill


# historic_buildings_ny_parquet

Read a Parquet or Geoparquet file and join with Overture.



# Join_with_Overture_parks_log

Read a Parquet or Geoparquet file and join with Overture.



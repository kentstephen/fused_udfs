# kontur_usa_r_6_file


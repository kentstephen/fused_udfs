# elevated_sentinel_hex_4_with_meta


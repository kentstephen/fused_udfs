# dsm_lidar_hex_ugsgs


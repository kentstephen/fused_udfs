# world_temp_plinio_3


# DEM_Terrarium_H3_Example

Read an image file with ImageIO.



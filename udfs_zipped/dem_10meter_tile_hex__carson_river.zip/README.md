# dem_10meter_tile_hex__carson_river


# h3_polygon_hospitals


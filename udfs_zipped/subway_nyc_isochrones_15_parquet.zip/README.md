# subway_nyc_isochrones_15_parquet

Read a Parquet or Geoparquet file.



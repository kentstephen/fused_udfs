# B12-B11-B8A (SWIR2, SWIR1, NIR)

# All infrared - pure moisture differentiation
# Driest areas appear bright/cyan
# Removes visible light interference
# Excellent for seeing through haze/smoke
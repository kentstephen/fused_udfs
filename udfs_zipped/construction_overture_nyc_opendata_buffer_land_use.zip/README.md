# construction_overture_nyc_opendata_buffer_land_use

Read a Parquet or Geoparquet file and join with Overture.



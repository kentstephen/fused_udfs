# Buildings_Proximity_to_Coffee_Shops_Bushwick

## Overview

Visualize Buildings Near Coffee Shops with Isochrones and H3 in Bushwick, Brooklyn.

Darker means higher `coffee_score`.


# carbon_plan_zarr_burn_probability_2

# Vida NEX-GDDP-based climate model

This UDF operates on a given bounding box ('bounds') to select and show the output from
Vida's processed NEX-GDDP-based ensemble climate data for the year 2080 by default.



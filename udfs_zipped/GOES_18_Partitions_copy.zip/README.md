# GOES_18_Partitions_copy


# world_temp_plinio_2


# USGS_snake_river_elevation_np_pd_demo

Read a GeoTIFF image file.



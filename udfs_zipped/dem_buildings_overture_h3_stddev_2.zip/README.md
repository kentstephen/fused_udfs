# dem_buildings_overture_h3_stddev_2


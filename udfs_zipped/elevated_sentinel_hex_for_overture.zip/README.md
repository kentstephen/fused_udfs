# elevated_sentinel_hex_for_overture


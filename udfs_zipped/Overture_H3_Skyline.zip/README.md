# Overture_H3_Skyline

## Overview

This UDF uses the `get_overture` helper function to access the Overture dataset hosted in Source Coop. It calculates building metrics, including perimeter and area, and aggregates them by H3 cell. The H3 resolution dynamically adjusts with zoom level unless a specific h3_size is provided.



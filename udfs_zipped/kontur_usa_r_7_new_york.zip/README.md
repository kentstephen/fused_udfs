# kontur_usa_r_7_new_york


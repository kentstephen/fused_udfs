# Join_with_Overture_parks

Read a Parquet or Geoparquet file and join with Overture.



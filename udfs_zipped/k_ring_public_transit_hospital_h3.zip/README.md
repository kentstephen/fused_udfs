# k_ring_public_transit_hospital_h3


@fused.udf
def udf(bounds: fused.types.Bounds = None, res:int =11, stats_type="mean", type='hex', color_scale:float=1):
    import pandas as pd
    import rioxarray
    from utils import aggregate_df_hex, url_to_plasma

    # convert bounds to tile
    common_utils = fused.load("https://github.com/fusedio/udfs/tree/2f41ae1/public/common/").utils
    tile = common_utils.get_tiles(bounds, clip=True)

    # 1. Initial parameters
    x, y, z = tile.iloc[0][["x", "y", "z"]]
    url = f"https://s3.amazonaws.com/elevation-tiles-prod/geotiff/{z}/{x}/{y}.tif"
    if type=='png':
        return url_to_plasma(url, min_max=(-1000,2000/color_scale**0.5), colormap='plasma')
    else:
        
        # x, y, z = tile.iloc[0][["x", "y", "z"]]
        # res_offset = 1  # lower makes the hex finer
        # res = max(min(int(3 + z / 1.5), 12) - res_offset, 2)
        print(res)
    
        # 2. Read tiff
        da_tiff = rioxarray.open_rasterio(url).squeeze(drop=True).rio.reproject("EPSG:4326")
        df_tiff = da_tiff.to_dataframe("data").reset_index()[["y", "x", "data"]]
    
        # 3. Hexagonify & aggregate
        df = aggregate_df_hex(
            df_tiff, res, latlng_cols=["y", "x"], stats_type=stats_type
        )
        df["elev_scale"] = int((15 - z) * 1)
        df["metric"]=df["metric"]*color_scale
        df = df[df["metric"] > 0]
        return df

# japan_vegetation_geoparquet


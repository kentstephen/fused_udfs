# USGS_snake_river_wyoming

Read a GeoTIFF image file.



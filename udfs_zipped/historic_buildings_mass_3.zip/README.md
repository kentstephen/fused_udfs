# historic_buildings_mass

Read a Parquet or Geoparquet file and join with Overture.



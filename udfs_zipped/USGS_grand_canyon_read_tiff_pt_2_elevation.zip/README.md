# USGS_grand_canyon_read_tiff_pt_2_elevation

Read a GeoTIFF image file.



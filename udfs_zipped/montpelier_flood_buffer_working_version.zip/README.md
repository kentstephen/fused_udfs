# montpelier_flood_buffer_working_version

Read a Parquet or Geoparquet file with DuckDB.



# Blank_Basemap

## Overview

This UDF is a blank vector tile. You can set its color in the Visualize tab.



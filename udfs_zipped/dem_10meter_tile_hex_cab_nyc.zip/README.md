# dem_10meter_tile_hex_cab_nyc


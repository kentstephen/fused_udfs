# japan_vegetation_geoparquet_2_h3_2


# chesapeake_bay_M130_2017_nc

Read a NetCDF image file with rioxarray.



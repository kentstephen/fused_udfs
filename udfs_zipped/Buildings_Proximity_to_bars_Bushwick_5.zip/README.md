# Buildings_Proximity_to_bars_Bushwick_5

## Overview

Visualize Buildings Near Coffee Shops with Isochrones and H3 in Bushwick, Brooklyn.

Darker means higher `coffee_score`.


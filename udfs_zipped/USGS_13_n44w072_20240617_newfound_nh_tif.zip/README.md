# USGS_13_n44w072_20240617_newfound_nh_tif

Read a GeoTIFF image file.



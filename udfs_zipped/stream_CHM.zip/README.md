# stream_CHM

Get Canopy Height Map from Meta's open dataset on AWS



# snake_river_read_tiff_pt_1


# USGS_denali_oct_2025

Read a GeoTIFF image file.



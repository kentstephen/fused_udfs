arr_to_h3 = fused.load("https://github.com/fusedio/udfs/tree/27999aa/public/common/").utils.arr_to_h3
get_data = fused.load('https://github.com/fusedio/udfs/tree/27999aa/public/NLCD_Tile_Example/').utils.get_data
rgb_to_hex = fused.load('https://github.com/fusedio/udfs/tree/27999aa/public/NLCD_Tile_Example/').utils.rgb_to_hex
nlcd_category_dict = fused.load('https://github.com/fusedio/udfs/tree/27999aa/public/NLCD_Tile_Example/').utils.nlcd_category_dict
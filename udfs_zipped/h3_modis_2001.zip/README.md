# h3_modis_2001

This is fork of: https://github.com/fusedio/udfs/tree/main/community/sina/DEM_Tile_Hexify


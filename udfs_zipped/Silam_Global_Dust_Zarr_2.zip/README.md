# Silam_Global_Dust_Zarr_2

## Silam Global Dust 

Visualize Zarr3 data from [Source Coop](https://source.coop/bkr/silam-dust)



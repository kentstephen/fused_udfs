# nsi_country_h3

Read a Parquet or Geoparquet file with DuckDB.



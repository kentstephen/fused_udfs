# bfp_EGY_parquet_works

Read a Parquet or Geoparquet file with DuckDB.



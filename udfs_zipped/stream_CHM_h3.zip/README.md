# stream_CHM_h3

Get Canopy Height Map from Meta's open dataset on AWS



# mount_washington_read_tiff_part_2


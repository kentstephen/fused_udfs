# modis_ndvi_for_collective_farms

Exported from Fused UDF Workbench




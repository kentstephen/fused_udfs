# deli_laoverture_h3_fsq_3


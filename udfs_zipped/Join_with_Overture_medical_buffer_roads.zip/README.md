# Join_with_Overture_medical_buffer_roads

Read a Parquet or Geoparquet file and join with Overture.



# power_plant_h3_zoom

## Overview

Use data from the Global Power Plant Database with an interactive zoom.

## External links

- [Data Source](https://datasets.wri.org/search)


# Nsi_Overture

## Overview

Spatial join between Overture polygons and NSI points to generate risk indices for each building.



# Join_with_Overture__parks_buffer

Read a Parquet or Geoparquet file and join with Overture.



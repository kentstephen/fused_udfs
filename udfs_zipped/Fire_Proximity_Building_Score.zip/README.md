# Fire_Proximity_Building_Score

## Buildings Fire Risk

This UDF can return 2 outputs:
1. Overture Building polygons with a rating of proximity to fire
2. H3 rollup of Overture Place categories

The fire rating is calculated with a buffer to represent proximity to a fire from the [WFIGS Current Interagency Fire Perimeters](https://data-nifc.opendata.arcgis.com/datasets/nifc::wfigs-current-interagency-fire-perimeters/about) dataset.



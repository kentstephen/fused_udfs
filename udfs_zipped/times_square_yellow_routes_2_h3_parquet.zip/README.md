# times_square_yellow_routes_2_h3_parquet

Read a Parquet or Geoparquet file.



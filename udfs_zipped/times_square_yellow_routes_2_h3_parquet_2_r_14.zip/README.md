# times_square_yellow_routes_2_h3_parquet_2_r_14

Read a Parquet or Geoparquet file.



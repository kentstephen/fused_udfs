visualize = fused.load(
    "https://github.com/fusedio/udfs/tree/2b25cb3/public/common/"
).utils.visualize
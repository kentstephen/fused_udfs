# join_with_overture_walking_ped_rec_park

Read a Parquet or Geoparquet file and join with Overture.



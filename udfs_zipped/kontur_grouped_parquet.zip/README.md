# kontur_grouped_parquet

Read a Parquet or Geoparquet file.



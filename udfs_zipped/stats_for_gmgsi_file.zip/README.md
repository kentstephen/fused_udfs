# stats_for_gmgsi_file


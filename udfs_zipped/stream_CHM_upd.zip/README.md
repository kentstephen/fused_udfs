# stream_CHM_upd

Get Canopy Height Map from Meta's open dataset on AWS



# world_temp_2024_r_4_parquet


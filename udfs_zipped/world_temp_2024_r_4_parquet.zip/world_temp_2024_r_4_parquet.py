@fused.udf
def udf():
    path = "s3://fused-users/stephenkentdata/temperature-t2m/world_temp_2024_r_4.parquet"
    # TODO: Read path here

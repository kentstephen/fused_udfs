# USGS_denali_oct_2025_sub_numpy_for_pandas_2_white_box_flow

Read a GeoTIFF image file.



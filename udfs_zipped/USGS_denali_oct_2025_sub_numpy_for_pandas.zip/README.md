# USGS_denali_oct_2025_sub_numpy_for_pandas

Read a GeoTIFF image file.



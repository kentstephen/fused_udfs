# terarrium_overture

Read an image file with ImageIO.



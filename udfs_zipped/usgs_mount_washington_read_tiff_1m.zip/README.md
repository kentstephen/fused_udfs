# usgs_mount_washington_read_tiff_1m


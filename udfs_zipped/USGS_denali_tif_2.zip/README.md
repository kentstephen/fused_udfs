# USGS_denali_tif_2

Read a GeoTIFF image file.



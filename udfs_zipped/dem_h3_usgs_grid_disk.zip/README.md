# dem_h3_usgs_grid_disk


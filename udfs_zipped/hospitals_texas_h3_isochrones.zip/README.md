# hospitals_texas_h3_isochrones


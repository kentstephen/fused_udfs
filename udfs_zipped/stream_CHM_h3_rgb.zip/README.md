# stream_CHM_h3_rgb

Get Canopy Height Map from Meta's open dataset on AWS



# kontur_japan_r_8_h3


# Vegetation_Segmentation_Example

## Overview

This app demonstrates how perform scalable vegetation analysis using classical computer vision techniques using Fused App.
## External links

- [Vegetation Segmentation UDF](https://www.fused.io/workbench/catalog/Vegetation_Segmentation-8262af53-aad3-4356-a566-74a07bcc7eef)



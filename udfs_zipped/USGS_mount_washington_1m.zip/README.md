# USGS_mount_washington_1m

Read a GeoTIFF image file.



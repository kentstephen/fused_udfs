# ndvi_buildings_overture


# Fire_Proximity_Buffer_upd_oct_2026_cali

## Fire Risk Buffer

Creates a buffer around a fire polygon. The fire rating is calculated with a buffer to represent proximity to a fire from the [WFIGS Current Interagency Fire Perimeters](https://data-nifc.opendata.arcgis.com/datasets/nifc::wfigs-current-interagency-fire-perimeters/about) dataset.



# egy_pd_2020_1km_UNadj_tif_hexify

Read a GeoTIFF image file.



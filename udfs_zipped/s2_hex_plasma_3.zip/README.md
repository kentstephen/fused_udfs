# s2_hex_plasma_3

